(function () {
  'use strict';

  if (!document.getElementById('btnAbrirEscaner')) return;

  var scanning    = false;
  var lastCode    = '';
  var lastTime    = 0;
  var DEBOUNCE_MS = 2500;

  var btnAbrir    = document.getElementById('btnAbrirEscaner');
  var modalEl     = document.getElementById('modalEscaner');
  var modalBS     = null;
  var btnCamara   = document.getElementById('escaner-btn-camara');
  var btnImagen   = document.getElementById('escaner-btn-imagen');
  var inputImagen = document.getElementById('escaner-input-imagen');
  var areaLector  = document.getElementById('escaner-area-lector');
  var statusEl    = document.getElementById('escaner-status');
  var resultadoEl = document.getElementById('escaner-resultado');

  var AREA_DEFAULT = '<div style="text-align:center;color:var(--tx-muted);padding:32px;">' +
    '<i class="fa-solid fa-barcode" style="font-size:3rem;display:block;margin-bottom:12px;opacity:.3;"></i>' +
    '<p style="font-size:.875rem;">Selecciona un modo para escanear</p></div>';

  // ── Abrir modal ──
  btnAbrir.addEventListener('click', function () {
    modalBS = bootstrap.Modal.getOrCreateInstance(modalEl);
    modalBS.show();
  });

  modalEl.addEventListener('hidden.bs.modal', function () {
    detenerCamara();
    resetUI();
  });

  // ── Cambiar modo ──
  btnCamara.addEventListener('click', function () {
    btnCamara.classList.add('active');
    btnImagen.classList.remove('active');
    inputImagen.style.display = 'none';
    iniciarCamara();
  });

  btnImagen.addEventListener('click', function () {
    btnImagen.classList.add('active');
    btnCamara.classList.remove('active');
    detenerCamara();
    areaLector.innerHTML = AREA_DEFAULT;
    inputImagen.style.display = 'block';
    inputImagen.click();
  });

  // ── Subir imagen ──
  inputImagen.addEventListener('change', function () {
    if (!this.files || !this.files[0]) return;
    var file = this.files[0];
    var objectUrl = URL.createObjectURL(file);
    setStatus('Analizando imagen...', 'info');
    resetResultado();

    Quagga.decodeSingle({
      src: objectUrl,
      numOfWorkers: 0,
      inputStream: { size: 1280 },
      decoder: {
        readers: ['ean_reader','ean_8_reader','code_128_reader','code_39_reader','upc_reader']
      },
      locate: true,
    }, function (result) {
      URL.revokeObjectURL(objectUrl);
      if (result && result.codeResult) {
        procesarCodigo(result.codeResult.code);
      } else {
        setStatus('No se pudo leer el código. Intenta que el código ocupe bien el encuadre.', 'error');
      }
    });

    this.value = '';
  });

  // ── Cámara ──
  function iniciarCamara() {
    detenerCamara();
    areaLector.innerHTML = '<div id="quagga-viewport" style="width:100%;"></div>';
    setStatus('Apunta la cámara al código de barras...', 'info');
    resetResultado();

    Quagga.init({
      inputStream: {
        type: 'LiveStream',
        target: document.getElementById('quagga-viewport'),
        constraints: { facingMode: 'environment' },
      },
      decoder: {
        readers: ['ean_reader','ean_8_reader','code_128_reader','code_39_reader','upc_reader']
      },
      locate: true,
    }, function (err) {
      if (err) {
        setStatus('No se pudo acceder a la cámara. Revisa los permisos.', 'error');
        return;
      }
      Quagga.start();
      scanning = true;
    });

    Quagga.onDetected(function (data) {
      var codigo = data.codeResult.code;
      var now    = Date.now();
      if (codigo === lastCode && (now - lastTime) < DEBOUNCE_MS) return;
      lastCode = codigo;
      lastTime = now;
      procesarCodigo(codigo);
    });
  }

  function detenerCamara() {
    if (scanning) {
      Quagga.offDetected();
      Quagga.stop();
      scanning = false;
    }
    areaLector.innerHTML = AREA_DEFAULT;
  }

  // ── Procesar código ──
  function procesarCodigo(codigo) {
    setStatus('Buscando: ' + codigo + '...', 'info');
    resetResultado();
    fetch('/productos/buscar-escaner/?codigo=' + encodeURIComponent(codigo))
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (data.estado === 'encontrado') mostrarEncontrado(data);
        else mostrarNoEncontrado(data);
      })
      .catch(function () {
        setStatus('Error de conexión al buscar el producto.', 'error');
      });
  }

  // ── Mostrar encontrado ──
  function mostrarEncontrado(data) {
    setStatus('', '');
    resultadoEl.innerHTML = `
      <div style="background:var(--c-success-l);border:1px solid rgba(39,174,96,0.25);border-radius:var(--r-md);padding:18px;margin-top:14px;">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">
          <div style="width:40px;height:40px;background:var(--c-success-l);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.2rem;color:var(--c-success);">
            <i class="fa-solid fa-circle-check"></i></div>
          <div>
            <div style="font-weight:700;font-size:.95rem;color:var(--tx-primary);">${data.nombre}</div>
            <div style="font-size:.78rem;color:var(--tx-muted);">Código: ${data.codigo} · Stock: <strong style="color:var(--c-success);">${data.stock}</strong></div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:10px;">
          <label style="font-size:.82rem;color:var(--tx-secondary);white-space:nowrap;">Agregar al stock:</label>
          <input type="number" id="escaner-cantidad" value="1" min="1" max="9999"
            style="width:80px;padding:7px 10px;background:var(--bg-input);border:1px solid var(--bd-default);border-radius:var(--r-sm);color:var(--tx-primary);font-size:.9rem;">
          <button onclick="window.escaner_agregarStock(${data.id})" class="btn btn-success btn-sm" style="flex:1;">
            <i class="fa-solid fa-plus"></i> Actualizar stock
          </button>
        </div>
      </div>`;
  }

  // ── Mostrar no encontrado ──
  function mostrarNoEncontrado(data) {
    var infoExtra = '';
    if (data.nombre_sugerido) {
      infoExtra = `<div style="background:var(--c-info-l);border:1px solid rgba(41,128,185,0.2);border-radius:var(--r-sm);padding:10px 14px;margin-bottom:12px;font-size:.82rem;">
        <i class="fa-solid fa-lightbulb" style="color:var(--c-info);margin-right:6px;"></i>
        <strong>Open Food Facts:</strong> ${data.nombre_sugerido}
        ${data.marca_sugerida ? ' · <em>' + data.marca_sugerida + '</em>' : ''}
        <br><small style="color:var(--tx-muted);">Se pre-llenará en el formulario.</small></div>`;
    }
    setStatus('', '');
    resultadoEl.innerHTML = `
      <div style="background:var(--c-gold-l);border:1px solid rgba(232,168,56,0.25);border-radius:var(--r-md);padding:18px;margin-top:14px;">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">
          <div style="width:40px;height:40px;background:var(--c-gold-l);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.2rem;color:var(--c-gold);">
            <i class="fa-solid fa-circle-question"></i></div>
          <div>
            <div style="font-weight:700;font-size:.95rem;color:var(--tx-primary);">Producto no registrado</div>
            <div style="font-size:.78rem;color:var(--tx-muted);">Código: ${data.codigo}</div>
          </div>
        </div>
        ${infoExtra}
        <button onclick="window.escaner_abrirFormulario('${data.codigo}','${(data.nombre_sugerido||'').replace(/'/g,"\\'")}','${(data.marca_sugerida||'').replace(/'/g,"\\'")}')"
          class="btn btn-warning w-100"><i class="fa-solid fa-plus"></i> Registrar este producto</button>
      </div>`;
  }

  // ── Actualizar stock ──
  window.escaner_agregarStock = function (productoId) {
    var cantidadEl = document.getElementById('escaner-cantidad');
    var cantidad   = parseInt(cantidadEl ? cantidadEl.value : 1);
    if (!cantidad || cantidad < 1) {
      Swal.fire({ icon:'warning', title:'Cantidad inválida', text:'Ingresa una cantidad mayor a 0.',
        background:'#0e1420', color:'#f0f4ff', confirmButtonColor:'#c0392b' });
      return;
    }
    var csrf = (document.cookie.split(';').map(c=>c.trim()).find(c=>c.startsWith('csrftoken='))||'').split('=')[1]||'';
    fetch('/productos/actualizar-stock-nuevo/', {
      method: 'POST',
      headers: { 'Content-Type':'application/json', 'X-CSRFToken':csrf },
      body: JSON.stringify({ id: productoId, cantidad: cantidad })
    }).then(r=>r.json()).then(function(data) {
      if (data.ok) {
        Swal.fire({ icon:'success', title:'Stock actualizado',
          html:'<strong>'+data.nombre+'</strong><br>Nuevo stock: <strong style="color:#27ae60;">'+data.stock_nuevo+'</strong>',
          background:'#0e1420', color:'#f0f4ff', confirmButtonColor:'#27ae60', timer:3000, timerProgressBar:true
        }).then(function(){ if(modalBS) modalBS.hide(); window.location.reload(); });
      } else {
        Swal.fire({ icon:'error', title:'Error', text:data.error,
          background:'#0e1420', color:'#f0f4ff', confirmButtonColor:'#c0392b' });
      }
    }).catch(function(){
      Swal.fire({ icon:'error', title:'Error de conexión',
        background:'#0e1420', color:'#f0f4ff', confirmButtonColor:'#c0392b' });
    });
  };

  // ── Abrir formulario ──
  window.escaner_abrirFormulario = function (codigo, nombre, marca) {
    if (modalBS) modalBS.hide();
    setTimeout(function () {
      var ic = document.querySelector('#modalAgregar [name="codigo_barras"]');
      var in_ = document.querySelector('#modalAgregar [name="nombre"]');
      if (ic) ic.value = codigo;
      if (in_ && nombre) in_.value = nombre;
      bootstrap.Modal.getOrCreateInstance(document.getElementById('modalAgregar')).show();
    }, 400);
  };

  function setStatus(msg, tipo) {
    if (!statusEl) return;
    statusEl.textContent = msg;
    statusEl.style.color = tipo==='error' ? 'var(--c-danger)' : tipo==='info' ? 'var(--tx-secondary)' : '';
  }
  function resetResultado() { if (resultadoEl) resultadoEl.innerHTML = ''; }
  function resetUI() {
    resetResultado();
    setStatus('', '');
    btnCamara.classList.remove('active');
    btnImagen.classList.remove('active');
    inputImagen.style.display = 'none';
    areaLector.innerHTML = AREA_DEFAULT;
  }

})();